


const myTitle = document.getElementsByClassName('myTitle')
myTitle[0].innerHTML = 'Hello Me'

const myIdTitle = document.getElementById('myIdTitle')
myIdTitle.innerHTML = 'Hello World'
myIdTitle.style.backgroundColor = 'pink'

const myClickEvent = (event) => {
    console.log('I am clicked', event.target.getAttribute('class'))
}

myIdTitle.addEventListener('dblclick', myClickEvent)

console.log('myTitle: ', myTitle)
console.log('myIdTitle: ', myIdTitle)

const list = ['Mango', 'Orange', 'Banana']
const myList = document.getElementById('myList')
let html = ''
for (let i = 0; i < list.length; i++) {
    html += `<li class="myListLIs"> ${list[i]} </li>`
}
myList.innerHTML = html


const myListLIs = document.querySelectorAll('.myListLIs')
for (let i = 0; i < myListLIs.length; i++) {
    const element = myListLIs[i]
    element.addEventListener('mouseover', (e) => {
        e.target.style.borderBottom = '2px solid red'
    })

    element.addEventListener('mouseleave', (e) => {
        e.target.style.borderBottom = 'none'
    })
}